package com.carrental;

import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/cars")
public class CarController {

    private final List<Car> cars = Arrays.asList(
            new Car(1, "Toyota Corolla", "2020", 50.0),
            new Car(2, "Honda Civic", "2019", 45.0),
            new Car(3, "Ford Mustang", "2021", 80.0));

    @GetMapping
    public List<Car> getCars() {
        return cars;
    }

    static class Car {
        private int id;
        private String name;
        private String model;
        private double pricePerDay;

        // Constructor, Getters, and Setters
        public Car(int id, String name, String model, double pricePerDay) {
            this.id = id;
            this.name = name;
            this.model = model;
            this.pricePerDay = pricePerDay;
        }
        // Getters and Setters
    }
}
