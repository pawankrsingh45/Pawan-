package com.carrental;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @PostMapping
    public String createBooking(@RequestBody Booking booking) {
        // Just return a success message for simplicity
        return "Booking successful for " + booking.getCustomerName();
    }

    static class Booking {
        private String customerName;
        private String customerEmail;
        private int carId;

        // Getters and Setters
    }
}
