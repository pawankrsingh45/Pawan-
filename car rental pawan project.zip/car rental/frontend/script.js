document.addEventListener('DOMContentLoaded', async () => {
    const carList = document.getElementById('car-list');
    const carSelect = document.getElementById('carSelect');
    const bookingForm = document.getElementById('booking-form');

    // Fetch cars
    const cars = await fetch('http://localhost:8080/api/cars').then(res => res.json());
    carList.innerHTML = cars.map(car => `
        <div>
            <h3>${car.name} (${car.model})</h3>
            <p>Price: $${car.pricePerDay}/day</p>
        </div>
    `).join('');
    carSelect.innerHTML = cars.map(car => `
        <option value="${car.id}">${car.name} (${car.model})</option>
    `).join('');

    // Handle form submission
    bookingForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const booking = {
            customerName: document.getElementById('customerName').value,
            customerEmail: document.getElementById('customerEmail').value,
            carId: parseInt(carSelect.value)
        };

        const response = await fetch('http://localhost:8080/api/bookings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(booking)
        });

        if (response.ok) {
            alert('Booking successful!');
        } else {
            alert('Booking failed.');
        }
    });
});
